//import UIKit
import Foundation







let words = ["Cat", "Chicken", "fish", "Dog",
             "Mouse", "Guinea Pig", "monkey"]

typealias Entry = (Character, [String])

func buildIndex(words: [String]) -> [Entry] {
  func firstLetter(str: String) -> Character {
    return Character(str.substringToIndex(str.startIndex.advancedBy(1)).uppercaseString)
  }
  
  
  return distinct(words.map(firstLetter))
    .map {
      (letter) -> Entry in
      
      return (letter, words.filter {
        (word) -> Bool in
        Character(word.substringToIndex(word.startIndex.advancedBy(1)).uppercaseString) == letter
        })
  }
}

print(buildIndex(words: words))



/*
 
let words = ["Cat", "Chicken", "fish", "Dog",
                      "Mouse", "Guinea Pig", "monkey"]

typealias Entry = (Character, [String])
func buildIndex(words: [String]) -> [Entry] {
  return [Entry]()
}
print(buildIndex(words))



func buildIndex(words: [String]) -> [Entry] {
  var result = [Entry]()
  
  var letters = [Character]()
  for word in words {
    let firstLetter = Character(word.substringToIndex(word.startIndex.advancedBy(1)).uppercaseString)
    
    if !letters.contains(firstLetter) {
      letters.append(firstLetter)
    }
  }
  
  for letter in letters {
    var wordsForLetter = [String]()
    for word in words {
      let firstLetter = Character(word.substringToIndex(word.startIndex.advancedBy(1)).uppercaseString)
      
      if firstLetter == letter {
        wordsForLetter.append(word)
      }
    }
    result.append((letter, wordsForLetter))
  }
  return result
}















 var evens = [Int]()




for i in 1...10 {
  if i % 2 == 0 {
    evens.append(i)
  }
}
print(evens)

///             Function filtr start

func isEven(number: Int) -> Bool {
  return number % 2 == 0
}
evens = Array(1...10).filter(isEven)
print(evens)



///             With clouser

evens = Array(1...10).filter { (number) in number % 2 == 0 }
print(evens)


evens = Array(1...10).filter { $0 % 2 == 0 }
print(evens)



func myFilter<T>(source: [T], predicate:(T) -> Bool) -> [T] {
  var result = [T]()
  for i in source {
    if predicate(i) {
      result.append(i)
    }
  }
  return result
}




var evens = [Int]()
for i in 1...10 {
  if i % 2 == 0 {
    evens.append(i)
  }
}
 
var evenSum = 0
for i in evens {
  evenSum += i
}
 
print(evenSum)


///             Reduce

evenSum = Array(1...10)
    .filter { (number) in number % 2 == 0 }
    .reduce(0) { (total, number) in total + number }
 
print(evenSum)




let maxNumber = Array(1...10)
            .reduce(0) { (total, number) in max(total, number) }
print(maxNumber)



let numbers = Array(1...10)
      .reduce("numbers: ") {(total, number) in total + "\(number) "}
print(numbers)




extension Array {
  func myReduce<T, U>(seed:U, combiner:(U, T) -> U) -> U {
    var current = seed
    for item in self {
      current = combiner(current, item as! T)
    }
    return current
  }
}


*/

